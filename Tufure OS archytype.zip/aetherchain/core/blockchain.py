"""
AetherChain Blockchain Implementation

Based on the AetherChain white paper, the blockchain is a chain of blocks where:
- Blocks link via H(B_{i-1}) to ensure chronological integrity
- Forks are resolved by the longest valid chain, weighted by cumulative PoC difficulty
"""

import hashlib
import json
import time
from typing import List, Dict, Any
from .block import Block
from .transaction import Transaction

class Blockchain:
    """
    AetherChain Blockchain class
    
    Manages the chain of blocks with:
    - Genesis block creation
    - Block validation
    - Chain integrity verification
    - Fork resolution
    """
    
    def __init__(self, difficulty: int = 2):
        """
        Initialize the blockchain
        
        Args:
            difficulty: Mining difficulty for Proof-of-Compute
        """
        self.chain: List[Block] = []
        self.difficulty = difficulty
        self.pending_transactions: List[Transaction] = []
        
        # Create genesis block
        self._create_genesis_block()
    
    def _create_genesis_block(self):
        """
        Create the genesis block (first block in the chain)
        """
        genesis_block = Block(
            index=0,
            transactions=[],
            previous_hash="0" * 64,
            timestamp=time.time()
        )
        genesis_block.mine_block(self.difficulty)
        self.chain.append(genesis_block)
    
    def get_latest_block(self) -> Block:
        """
        Get the latest block in the chain
        
        Returns:
            Block: The most recent block
        """
        return self.chain[-1]
    
    def add_transaction(self, transaction: Transaction) -> bool:
        """
        Add a transaction to the pending transactions pool
        
        Args:
            transaction: Transaction to add
            
        Returns:
            bool: True if transaction was added, False otherwise
        """
        # Basic validation
        if not isinstance(transaction, Transaction):
            return False
            
        # In a real implementation, we would also:
        # - Verify transaction signature
        # - Check if inputs are valid and unspent
        # - Validate transaction structure
        
        self.pending_transactions.append(transaction)
        return True
    
    def mine_pending_transactions(self, reward_address: str = None):
        """
        Mine pending transactions into a new block
        
        Args:
            reward_address: Address to receive mining reward (optional)
        """
        if not self.pending_transactions:
            return None
            
        # Create reward transaction if address provided
        if reward_address:
            reward_tx = Transaction(
                inputs=[],  # Coinbase transaction has no inputs
                outputs=[{"address": reward_address, "amount": 1.0}]  # Mining reward
            )
            self.pending_transactions.append(reward_tx)
        
        # Create new block
        new_block = Block(
            index=len(self.chain),
            transactions=self.pending_transactions,
            previous_hash=self.get_latest_block().hash()
        )
        
        # Mine the block
        new_block.mine_block(self.difficulty)
        
        # Add to chain
        self.chain.append(new_block)
        
        # Clear pending transactions
        self.pending_transactions = []
        
        return new_block
    
    def is_chain_valid(self) -> bool:
        """
        Validate the integrity of the entire blockchain
        
        Returns:
            bool: True if chain is valid, False otherwise
        """
        # Check genesis block
        if len(self.chain) == 0:
            return False
            
        # Check each block
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]
            
            # Verify current block's hash
            if current_block.hash() != current_block.hash():
                print(f"Invalid hash at block {i}")
                return False
                
            # Verify previous hash linkage
            if current_block.previous_hash != previous_block.hash():
                print(f"Invalid previous hash at block {i}")
                return False
                
            # Verify block is properly mined
            target = "0" * self.difficulty
            if current_block.hash()[:self.difficulty] != target:
                print(f"Block {i} not properly mined")
                return False
                
        return True
    
    def resolve_forks(self, other_chain: 'Blockchain') -> bool:
        """
        Resolve forks by selecting the longest valid chain
        
        According to the white paper: "Forks are resolved by the longest valid chain, 
        weighted by cumulative PoC difficulty"
        
        Args:
            other_chain: Another blockchain to compare with
            
        Returns:
            bool: True if this chain was replaced, False otherwise
        """
        # In a real implementation, we would weight by cumulative PoC difficulty
        # For now, we'll use chain length as a simplified approach
        
        if len(other_chain.chain) > len(self.chain) and other_chain.is_chain_valid():
            self.chain = other_chain.chain.copy()
            return True
            
        return False
    
    def get_balance(self, address: str) -> float:
        """
        Calculate the balance of an address
        
        Args:
            address: Address to check balance for
            
        Returns:
            float: Balance of the address
        """
        balance = 0.0
        
        # Iterate through all blocks and transactions
        for block in self.chain:
            for transaction in block.transactions:
                # Add outputs to this address
                for output in transaction.outputs:
                    if output.get('address') == address:
                        balance += output.get('amount', 0)
                        
                # Subtract inputs from this address (simplified)
                # In a real implementation, we would track unspent transaction outputs (UTXOs)
        
        return balance
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert blockchain to dictionary representation
        
        Returns:
            dict: Dictionary representation of the blockchain
        """
        return {
            'chain': [block.to_dict() for block in self.chain],
            'difficulty': self.difficulty,
            'pending_transactions': [tx.to_dict() for tx in self.pending_transactions]
        }
    
    def serialize(self) -> str:
        """
        Serialize blockchain to JSON string
        
        Returns:
            str: JSON string representation
        """
        return json.dumps(self.to_dict(), sort_keys=True, indent=2)

# Example usage
if __name__ == "__main__":
    # Create a blockchain
    blockchain = Blockchain(difficulty=2)
    
    print(f"Genesis block hash: {blockchain.get_latest_block().hash()}")
    
    # Create sample transactions
    tx1 = Transaction(
        inputs=[{"tx_id": "genesis", "output_index": 0, "amount": 100}],
        outputs=[{"address": "addr1", "amount": 100}]
    )
    
    tx2 = Transaction(
        inputs=[{"tx_id": "tx1", "output_index": 0, "amount": 100}],
        outputs=[{"address": "addr2", "amount": 50}, {"address": "addr3", "amount": 50}]
    )
    
    # Add transactions to blockchain
    blockchain.add_transaction(tx1)
    blockchain.add_transaction(tx2)
    
    print(f"Pending transactions: {len(blockchain.pending_transactions)}")
    
    # Mine pending transactions
    new_block = blockchain.mine_pending_transactions(reward_address="miner1")
    print(f"Mined new block: {new_block.hash()}")
    
    print(f"Chain valid: {blockchain.is_chain_valid()}")
    print(f"Chain length: {len(blockchain.chain)}")
    
    # Check balances
    print(f"addr1 balance: {blockchain.get_balance('addr1')}")
    print(f"addr2 balance: {blockchain.get_balance('addr2')}")
    print(f"addr3 balance: {blockchain.get_balance('addr3')}")
    print(f"miner1 balance: {blockchain.get_balance('miner1')}")