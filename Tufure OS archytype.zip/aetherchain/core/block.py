"""
AetherChain Block Implementation

Based on the AetherChain white paper, blocks form the blockchain structure:
- H(B_{i-1}): Hash of the previous block
- M(T_1, ..., T_m): Merkle root of transactions
- σ: Network signature aggregate
- PoC(B_i): Proof-of-Compute
"""

import hashlib
import json
import time
from typing import List, Dict, Any
from .transaction import Transaction

class Block:
    """
    AetherChain Block class
    
    Represents a block in the blockchain containing:
    - Previous block hash
    - List of transactions
    - Merkle root of transactions
    - Timestamp
    - Network signature aggregate
    - Proof-of-Compute
    """
    
    def __init__(self, index: int, transactions: List[Transaction], previous_hash: str, 
                 timestamp: float = None, nonce: int = 0):
        """
        Initialize a new block
        
        Args:
            index: Block index in the chain
            transactions: List of transactions in the block
            previous_hash: Hash of the previous block
            timestamp: Block creation timestamp
            nonce: Nonce for Proof-of-Compute
        """
        self.index = index
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.timestamp = timestamp or time.time()
        self.nonce = nonce
        self.merkle_root = self._calculate_merkle_root()
        self.proof_of_compute = None  # Will be set during mining
        self.network_signature = None  # Will be set by network layer
        
    def _calculate_merkle_root(self) -> str:
        """
        Calculate the Merkle root of transactions
        
        Returns:
            str: Hexadecimal representation of the Merkle root
        """
        if not self.transactions:
            return hashlib.sha256(b"").hexdigest()
            
        # Get transaction hashes
        transaction_hashes = [tx.hash() for tx in self.transactions]
        
        # Build Merkle tree
        while len(transaction_hashes) > 1:
            # Pad with last hash if odd number
            if len(transaction_hashes) % 2 == 1:
                transaction_hashes.append(transaction_hashes[-1])
            
            # Combine pairs
            new_hashes = []
            for i in range(0, len(transaction_hashes), 2):
                combined = transaction_hashes[i] + transaction_hashes[i+1]
                new_hashes.append(hashlib.sha256(combined.encode()).hexdigest())
            
            transaction_hashes = new_hashes
            
        return transaction_hashes[0]
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert block to dictionary representation
        
        Returns:
            dict: Dictionary representation of the block
        """
        return {
            'index': self.index,
            'transactions': [tx.to_dict() for tx in self.transactions],
            'previous_hash': self.previous_hash,
            'timestamp': self.timestamp,
            'nonce': self.nonce,
            'merkle_root': self.merkle_root,
            'proof_of_compute': self.proof_of_compute,
            'network_signature': self.network_signature
        }
    
    def serialize(self) -> str:
        """
        Serialize block to JSON string
        
        Returns:
            str: JSON string representation
        """
        # Convert transactions to serializable format
        data = self.to_dict()
        return json.dumps(data, sort_keys=True)
    
    def hash(self) -> str:
        """
        Calculate SHA-256 hash of the block header
        
        Returns:
            str: Hexadecimal representation of the hash
        """
        # Block header includes: index, previous_hash, merkle_root, timestamp, nonce
        header_data = f"{self.index}{self.previous_hash}{self.merkle_root}{self.timestamp}{self.nonce}"
        return hashlib.sha256(header_data.encode('utf-8')).hexdigest()
    
    def mine_block(self, difficulty: int):
        """
        Mine the block using Proof-of-Compute
        
        Args:
            difficulty: Target difficulty for mining
        """
        # This is a simplified version - in practice, this would involve:
        # 1. Executing a subset of transactions in an emulator
        # 2. Generating a ZK-SNARK proof that outputs match commitments
        # 3. Finding a nonce that satisfies the PoC puzzle
        
        target = "0" * difficulty
        while self.hash()[:difficulty] != target:
            self.nonce += 1
            
        # In a real implementation, we would also:
        # - Generate ZK-SNARK proof (π)
        # - Include energy sample from TSU
        # - Store the full PoC(B_i) = (n, π, energy_sample)
        self.proof_of_compute = {
            'nonce': self.nonce,
            'proof': 'zk_snark_proof_placeholder',  # Would be actual ZK-SNARK proof
            'energy_sample': 'tsu_energy_sample_placeholder'  # Would be actual TSU sample
        }

# Example usage
if __name__ == "__main__":
    # Create sample transactions
    tx1 = Transaction(
        inputs=[{"tx_id": "tx1", "output_index": 0, "amount": 100}],
        outputs=[{"address": "addr1", "amount": 100}]
    )
    
    tx2 = Transaction(
        inputs=[{"tx_id": "tx2", "output_index": 0, "amount": 50}],
        outputs=[{"address": "addr2", "amount": 25}, {"address": "addr3", "amount": 25}]
    )
    
    # Create a block
    block = Block(
        index=1,
        transactions=[tx1, tx2],
        previous_hash="0000000000000000000000000000000000000000000000000000000000000000"
    )
    
    print(f"Block hash: {block.hash()}")
    print(f"Merkle root: {block.merkle_root}")
    
    # Mine the block (simplified)
    print("Mining block...")
    block.mine_block(difficulty=2)
    print(f"Mined block hash: {block.hash()}")
    print(f"Proof of Compute: {block.proof_of_compute}")