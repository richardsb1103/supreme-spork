"""
AetherChain Transaction Implementation

Based on the AetherChain white paper, transactions capture user commands as structured data:
- Inputs: References to prior outputs
- Outputs: Intended states
- Metadata: Timestamp, public key signature (ECDSA secp256k1), and nonce
"""

import hashlib
import time
import json
from typing import List, Dict, Any
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature

class Transaction:
    """
    AetherChain Transaction class
    
    Represents a user command as a structured transaction with:
    - Inputs: References to prior outputs
    - Outputs: Intended states
    - Metadata: Timestamp, public key signature, and nonce
    """
    
    def __init__(self, inputs: List[Dict], outputs: List[Dict], public_key: bytes = None):
        """
        Initialize a new transaction
        
        Args:
            inputs: List of input references (prior outputs)
            outputs: List of intended output states
            public_key: Public key for signature verification
        """
        self.inputs = inputs
        self.outputs = outputs
        self.timestamp = time.time()
        self.public_key = public_key
        self.nonce = self._generate_nonce()
        self.signature = None
        
    def _generate_nonce(self) -> int:
        """
        Generate a nonce for the transaction
        
        Returns:
            int: A random nonce value
        """
        import random
        return random.randint(0, 2**64)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert transaction to dictionary representation
        
        Returns:
            dict: Dictionary representation of the transaction
        """
        return {
            'inputs': self.inputs,
            'outputs': self.outputs,
            'timestamp': self.timestamp,
            'nonce': self.nonce,
            'public_key': self.public_key.hex() if self.public_key else None,
            'signature': self.signature.hex() if self.signature else None
        }
    
    def serialize(self) -> str:
        """
        Serialize transaction to JSON string (without signature for signing)
        
        Returns:
            str: JSON string representation
        """
        data = self.to_dict()
        # Remove signature for signing
        data['signature'] = None
        return json.dumps(data, sort_keys=True)
    
    def hash(self) -> str:
        """
        Calculate SHA-256 hash of the transaction
        
        Returns:
            str: Hexadecimal representation of the hash
        """
        data = self.serialize().encode('utf-8')
        return hashlib.sha256(data).hexdigest()
    
    def sign(self, private_key: bytes):
        """
        Sign the transaction with a private key using ECDSA (secp256k1)
        
        Args:
            private_key: Private key bytes for signing
        """
        # Load private key
        private_key_obj = serialization.load_der_private_key(
            private_key, password=None, backend=default_backend()
        )
        
        # Serialize transaction without signature
        data = self.serialize().encode('utf-8')
        
        # Sign the data
        signature = private_key_obj.sign(data, ec.ECDSA(hashes.SHA256()))
        self.signature = signature
    
    def verify_signature(self) -> bool:
        """
        Verify the transaction signature
        
        Returns:
            bool: True if signature is valid, False otherwise
        """
        if not self.signature or not self.public_key:
            return False
            
        try:
            # Load public key
            public_key_obj = serialization.load_der_public_key(
                bytes.fromhex(self.public_key.hex()), backend=default_backend()
            )
            
            # Serialize transaction without signature for verification
            data = self.serialize().encode('utf-8')
            
            # Verify signature
            public_key_obj.verify(
                self.signature, data, ec.ECDSA(hashes.SHA256())
            )
            return True
        except (InvalidSignature, ValueError):
            return False

# Example usage
if __name__ == "__main__":
    # Generate a key pair for testing
    private_key = ec.generate_private_key(ec.SECP256K1(), default_backend())
    public_key = private_key.public_key()
    
    # Serialize keys
    private_key_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Create a sample transaction
    inputs = [
        {
            "tx_id": "abc123",
            "output_index": 0,
            "amount": 100
        }
    ]
    
    outputs = [
        {
            "address": "xyz789",
            "amount": 50
        },
        {
            "address": "def456",
            "amount": 50
        }
    ]
    
    # Create transaction
    tx = Transaction(inputs, outputs, public_key_bytes)
    
    # Sign transaction
    tx.sign(private_key_bytes)
    
    # Verify signature
    is_valid = tx.verify_signature()
    print(f"Signature valid: {is_valid}")
    
    # Print transaction hash
    print(f"Transaction hash: {tx.hash()}")