"""
AetherChain P2P Network Implementation

Based on the AetherChain white paper, the network:
- Forms a P2P weave using libp2p for discovery
- Commands propagate via flood routing
- Uses gossip for mempool sync
- Implements Byzantine Fault Tolerance (BFT) thresholds
"""

import hashlib
import json
import time
import threading
from typing import List, Dict, Any, Set
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.transaction import Transaction
from core.block import Block
from core.blockchain import Blockchain

class P2PNetworkNode:
    """
    AetherChain P2P Network Node class
    
    Implements the network layer with:
    - Node discovery using libp2p concepts
    - Flood routing for command propagation
    - Gossip protocol for mempool synchronization
    - BFT threshold management
    """
    
    def __init__(self, node_id: str, host: str = "127.0.0.1", port: int = 8000):
        """
        Initialize a P2P network node
        
        Args:
            node_id: Unique identifier for the node
            host: Host address for the node
            port: Port number for the node
        """
        self.node_id = node_id
        self.host = host
        self.port = port
        self.peers: Dict[str, Dict[str, Any]] = {}  # peer_id -> peer_info
        self.blockchain = Blockchain()
        self.mempool: List[Transaction] = []
        self.known_blocks: Set[str] = set()
        self.known_transactions: Set[str] = set()
        self.bft_threshold = 1/3  # <1/3 malicious nodes as in PBFT
        self.is_running = False
        
    def start(self):
        """
        Start the P2P network node
        """
        self.is_running = True
        print(f"Starting AetherChain node {self.node_id} on {self.host}:{self.port}")
        
        # In a real implementation, this would:
        # 1. Initialize libp2p host
        # 2. Set up network listeners
        # 3. Start peer discovery
        # 4. Begin gossip protocols
        
    def stop(self):
        """
        Stop the P2P network node
        """
        self.is_running = False
        print(f"Stopping AetherChain node {self.node_id}")
        
    def add_peer(self, peer_id: str, host: str, port: int):
        """
        Add a peer to the network
        
        Args:
            peer_id: Unique identifier for the peer
            host: Host address of the peer
            port: Port number of the peer
        """
        self.peers[peer_id] = {
            'host': host,
            'port': port,
            'last_seen': time.time(),
            'status': 'connected'
        }
        print(f"Added peer {peer_id} at {host}:{port}")
        
    def remove_peer(self, peer_id: str):
        """
        Remove a peer from the network
        
        Args:
            peer_id: Unique identifier for the peer
        """
        if peer_id in self.peers:
            del self.peers[peer_id]
            print(f"Removed peer {peer_id}")
            
    def broadcast_transaction(self, transaction: Transaction):
        """
        Broadcast a transaction to all peers using flood routing
        
        According to the white paper:
        "Commands propagate via flood routing, with gossip for mempool sync"
        
        Args:
            transaction: Transaction to broadcast
        """
        tx_hash = transaction.hash()
        
        # Check if we've already seen this transaction
        if tx_hash in self.known_transactions:
            return
            
        # Add to known transactions
        self.known_transactions.add(tx_hash)
        
        # Add to local mempool
        self.mempool.append(transaction)
        
        # In a real implementation, this would:
        # 1. Serialize transaction
        # 2. Send to all connected peers
        # 3. Track propagation to avoid loops
        
        print(f"Broadcasting transaction {tx_hash} to {len(self.peers)} peers")
        
        # Simulate sending to peers
        for peer_id in self.peers:
            print(f"  -> Sent to peer {peer_id}")
            
    def broadcast_block(self, block: Block):
        """
        Broadcast a block to all peers using flood routing
        
        Args:
            block: Block to broadcast
        """
        block_hash = block.hash()
        
        # Check if we've already seen this block
        if block_hash in self.known_blocks:
            return
            
        # Add to known blocks
        self.known_blocks.add(block_hash)
        
        # In a real implementation, this would:
        # 1. Serialize block
        # 2. Send to all connected peers
        # 3. Track propagation to avoid loops
        
        print(f"Broadcasting block {block_hash} to {len(self.peers)} peers")
        
        # Simulate sending to peers
        for peer_id in self.peers:
            print(f"  -> Sent to peer {peer_id}")
            
    def sync_mempool(self):
        """
        Synchronize mempool with peers using gossip protocol
        
        According to the white paper:
        "Commands propagate via flood routing, with gossip for mempool sync"
        """
        # In a real implementation, this would:
        # 1. Periodically exchange mempool state with peers
        # 2. Request missing transactions
        # 3. Remove expired transactions
        # 4. Maintain BFT thresholds
        
        print(f"Syncing mempool with {len(self.peers)} peers")
        print(f"Local mempool size: {len(self.mempool)}")
        
    def handle_incoming_transaction(self, transaction: Transaction) -> bool:
        """
        Handle an incoming transaction from a peer
        
        Args:
            transaction: Received transaction
            
        Returns:
            bool: True if transaction is valid and accepted, False otherwise
        """
        tx_hash = transaction.hash()
        
        # Check if we've already seen this transaction
        if tx_hash in self.known_transactions:
            return False
            
        # Validate transaction
        if not self._validate_transaction(transaction):
            print(f"Invalid transaction {tx_hash} received")
            return False
            
        # Add to known transactions
        self.known_transactions.add(tx_hash)
        
        # Add to local mempool
        self.mempool.append(transaction)
        
        print(f"Accepted transaction {tx_hash}")
        return True
        
    def handle_incoming_block(self, block: Block) -> bool:
        """
        Handle an incoming block from a peer
        
        Args:
            block: Received block
            
        Returns:
            bool: True if block is valid and accepted, False otherwise
        """
        block_hash = block.hash()
        
        # Check if we've already seen this block
        if block_hash in self.known_blocks:
            return False
            
        # Validate block
        if not self._validate_block(block):
            print(f"Invalid block {block_hash} received")
            return False
            
        # Add to known blocks
        self.known_blocks.add(block_hash)
        
        # Add to blockchain
        self.blockchain.chain.append(block)
        
        print(f"Accepted block {block_hash}")
        return True
        
    def _validate_transaction(self, transaction: Transaction) -> bool:
        """
        Validate a transaction
        
        Args:
            transaction: Transaction to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        # In a real implementation, this would:
        # 1. Verify transaction signature
        # 2. Check if inputs are valid and unspent
        # 3. Validate transaction structure
        # 4. Check against BFT thresholds
        
        # For simulation, we'll do basic validation
        try:
            # Check if transaction has inputs and outputs
            if not transaction.inputs or not transaction.outputs:
                return False
                
            # Check if transaction is properly formed
            if not transaction.hash():
                return False
                
            return True
        except Exception:
            return False
            
    def _validate_block(self, block: Block) -> bool:
        """
        Validate a block
        
        Args:
            block: Block to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        # In a real implementation, this would:
        # 1. Verify block hash meets difficulty target
        # 2. Validate Merkle root
        # 3. Check Proof-of-Compute
        # 4. Verify network signature aggregate
        # 5. Check against BFT thresholds
        
        # For simulation, we'll do basic validation
        try:
            # Check if block is properly formed
            if not block.hash():
                return False
                
            # Check if previous hash is valid
            if block.index > 0 and not block.previous_hash:
                return False
                
            return True
        except Exception:
            return False
            
    def get_network_status(self) -> Dict[str, Any]:
        """
        Get the current network status
        
        Returns:
            dict: Network status information
        """
        return {
            'node_id': self.node_id,
            'host': self.host,
            'port': self.port,
            'peers_count': len(self.peers),
            'mempool_size': len(self.mempool),
            'blockchain_height': len(self.blockchain.chain),
            'known_blocks': len(self.known_blocks),
            'known_transactions': len(self.known_transactions),
            'bft_threshold': self.bft_threshold,
            'is_running': self.is_running
        }

# Example usage
if __name__ == "__main__":
    # Create a network node
    node = P2PNetworkNode("node_001", "127.0.0.1", 8000)
    
    # Start the node
    node.start()
    
    # Add some peers
    node.add_peer("peer_001", "127.0.0.1", 8001)
    node.add_peer("peer_002", "127.0.0.1", 8002)
    
    # Create sample transactions
    tx1 = Transaction(
        inputs=[{"tx_id": "input1", "output_index": 0, "amount": 100}],
        outputs=[{"address": "addr1", "amount": 100}]
    )
    
    tx2 = Transaction(
        inputs=[{"tx_id": "input2", "output_index": 0, "amount": 50}],
        outputs=[{"address": "addr2", "amount": 25}, {"address": "addr3", "amount": 25}]
    )
    
    # Broadcast transactions
    node.broadcast_transaction(tx1)
    node.broadcast_transaction(tx2)
    
    # Create a sample block
    block = Block(
        index=1,
        transactions=[tx1, tx2],
        previous_hash="0" * 64
    )
    
    # Broadcast block
    node.broadcast_block(block)
    
    # Sync mempool
    node.sync_mempool()
    
    # Check network status
    status = node.get_network_status()
    print(f"Network status: {status}")
    
    # Stop the node
    node.stop()