"""
AetherChain Security Model Implementation

Based on the AetherChain white paper, security mechanisms include:
- Protection against double-execution (replay) attacks
- Forking attack prevention
- Configuration attack mitigation
- Mathematical security model based on binomial tail probabilities
- Post-quantum cryptography support
"""

import hashlib
import math
from typing import List, Dict, Any
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from core.transaction import Transaction
from core.block import Block
from core.blockchain import Blockchain

class SecurityModel:
    """
    AetherChain Security Model class
    
    Implements security mechanisms with:
    - Double-execution attack prevention
    - Forking attack resistance
    - Configuration attack mitigation
    - Mathematical security analysis
    - Post-quantum cryptography support
    """
    
    def __init__(self, blockchain: Blockchain):
        """
        Initialize the security model
        
        Args:
            blockchain: Blockchain instance to protect
        """
        self.blockchain = blockchain
        self.seen_transactions = set()  # For double-execution prevention
        self.seen_nonces = set()  # For replay attack prevention
        self.delta_merkle_updates = []  # For configuration attack mitigation
        
    def prevent_double_execution(self, transaction: Transaction) -> bool:
        """
        Prevent double-execution (replay) attacks
        
        According to the white paper:
        "To prevent double-execution (e.g., reusing a memory allocation), we employ 
        a timestamp server: transactions are hashed into a Merkle tree, with the root 
        timestamped via a distributed clock synced over gossip protocols"
        
        Args:
            transaction: Transaction to check
            
        Returns:
            bool: True if transaction is safe to execute, False if it's a replay
        """
        tx_hash = transaction.hash()
        
        # Check if we've seen this transaction before
        if tx_hash in self.seen_transactions:
            print(f"Double-execution attempt detected for transaction {tx_hash}")
            return False
            
        # Check if we've seen this nonce before (from same public key)
        if transaction.public_key and transaction.nonce:
            nonce_key = f"{transaction.public_key.hex()}_{transaction.nonce}"
            if nonce_key in self.seen_nonces:
                print(f"Replay attack detected for nonce {transaction.nonce}")
                return False
                
        # Add to seen sets
        self.seen_transactions.add(tx_hash)
        if transaction.public_key:
            nonce_key = f"{transaction.public_key.hex()}_{transaction.nonce}"
            self.seen_nonces.add(nonce_key)
            
        return True
    
    def calculate_attack_probability(self, attacker_hash_power: float, 
                                   confirmations: int) -> float:
        """
        Calculate the probability of a successful attack
        
        According to the white paper:
        "The probability P_k an attacker catches up after k blocks behind is the binomial tail:
        P_k = sum_{j=0}^k (k choose j) p^j q^{k-j} (for p <= q)
        
        More precisely, from Bitcoin's derivation: The prob attacker ever catches up is
        P = 1 - (q/p)^{z+1} / (1 - q/p) for p != q, 1 for p = q"
        
        Args:
            attacker_hash_power: Fraction of hash power controlled by attacker (p)
            confirmations: Number of confirmations (z)
            
        Returns:
            float: Probability of successful attack
        """
        p = attacker_hash_power  # Attacker hash power fraction
        q = 1 - p  # Honest hash power fraction
        z = confirmations  # Number of confirmations
        
        # Handle edge cases
        if p >= q:
            # If attacker has more power, they can eventually catch up
            if p == q and p == 0.5:
                # Equal power case
                return 1.0
            elif p > 0.5:
                # Attacker majority case
                return 0.99  # Very high probability, but not certain
            else:
                # Normal case
                pass
        
        # Calculate attack probability using Bitcoin's formula
        if abs(q - p) < 1e-10:  # p ≈ q
            return 1.0
        else:
            # P = 1 - (q/p)^(z+1) / (1 - q/p)
            ratio = q / p
            numerator = ratio ** (z + 1)
            denominator = 1 - ratio
            probability = 1 - (numerator / denominator)
            return max(0.0, min(1.0, probability))  # Clamp to [0,1]
    
    def is_fork_safe(self, chain_length: int, attacker_hash_power: float) -> bool:
        """
        Determine if the chain is safe from forking attacks
        
        According to the white paper:
        "Against 51% attacks: PoC's ZK layer requires majority collusion on proofs, 
        infeasible due to MPC thresholds"
        
        Args:
            chain_length: Length of the chain
            attacker_hash_power: Fraction of hash power controlled by attacker
            
        Returns:
            bool: True if chain is safe from forking attacks
        """
        # Calculate attack probability
        attack_prob = self.calculate_attack_probability(attacker_hash_power, chain_length)
        
        # Consider safe if attack probability is below threshold
        safety_threshold = 0.000001  # 10^-6 as mentioned in the white paper
        
        # Additional protection from PoC's ZK layer
        # Even if attacker has majority hash power, they need MPC collusion
        if attacker_hash_power > 0.51:
            # Additional security from MPC thresholds
            mpc_security_factor = 0.1  # 10% additional security from MPC
            adjusted_prob = attack_prob * (1 - mpc_security_factor)
            return adjusted_prob < safety_threshold
            
        return attack_prob < safety_threshold
    
    def apply_delta_merkle_update(self, old_state: Dict[str, Any], 
                                 new_state: Dict[str, Any]) -> bool:
        """
        Apply delta-Merkle updates to prevent configuration attacks
        
        According to the white paper:
        "Configuration attacks (e.g., vuln injection) are mitigated by delta-Merkle updates:
        Only verified diffs apply, sampled for anomalies"
        
        Args:
            old_state: Previous system state
            new_state: New system state
            
        Returns:
            bool: True if update is safe to apply, False otherwise
        """
        # Calculate Merkle roots for both states
        old_root = self._calculate_merkle_root(old_state)
        new_root = self._calculate_merkle_root(new_state)
        
        # Create delta
        delta = {
            'old_root': old_root,
            'new_root': new_root,
            'timestamp': self._get_current_time(),
            'diffs': self._calculate_diffs(old_state, new_state)
        }
        
        # Store delta for anomaly detection
        self.delta_merkle_updates.append(delta)
        
        # Sample for anomalies (simplified)
        is_anomalous = self._detect_anomalies(delta)
        
        if is_anomalous:
            print("Anomalous delta-Merkle update detected")
            return False
            
        return True
    
    def _calculate_merkle_root(self, data: Dict[str, Any]) -> str:
        """
        Calculate Merkle root of data
        
        Args:
            data: Data to calculate Merkle root for
            
        Returns:
            str: Merkle root hash
        """
        # Simplified implementation
        data_str = str(sorted(data.items()))
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def _calculate_diffs(self, old_state: Dict[str, Any], 
                        new_state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Calculate differences between two states
        
        Args:
            old_state: Previous state
            new_state: New state
            
        Returns:
            list: List of differences
        """
        diffs = []
        
        # Find added/modified keys
        for key, value in new_state.items():
            if key not in old_state:
                diffs.append({'type': 'add', 'key': key, 'value': value})
            elif old_state[key] != value:
                diffs.append({
                    'type': 'modify', 
                    'key': key, 
                    'old_value': old_state[key], 
                    'new_value': value
                })
                
        # Find removed keys
        for key in old_state:
            if key not in new_state:
                diffs.append({'type': 'remove', 'key': key, 'value': old_state[key]})
                
        return diffs
    
    def _detect_anomalies(self, delta: Dict[str, Any]) -> bool:
        """
        Detect anomalies in delta-Merkle updates
        
        Args:
            delta: Delta update to analyze
            
        Returns:
            bool: True if anomalies detected, False otherwise
        """
        # In a real implementation, this would use statistical analysis
        # For simulation, we'll use a simple heuristic
        
        # Check if too many changes
        if len(delta['diffs']) > 100:  # Arbitrary threshold
            return True
            
        # Check for sensitive key modifications
        sensitive_keys = ['kernel', 'security', 'crypto', 'permissions']
        for diff in delta['diffs']:
            for sensitive_key in sensitive_keys:
                if sensitive_key in diff['key'].lower():
                    # For sensitive keys, require additional verification
                    return True  # In real implementation, this would trigger verification
                    
        return False
    
    def regenerate_post_quantum_keys(self) -> Dict[str, Any]:
        """
        Regenerate post-quantum keys using TSU entropy
        
        According to the white paper:
        "Encryption resilience: Post-quantum Kyber keys regenerate via TSU 
        entropy if tampered"
        
        Returns:
            dict: New post-quantum key pair
        """
        # In a real implementation, this would:
        # 1. Interface with TSU for entropy
        # 2. Generate Kyber key pair
        # 3. Update key storage securely
        
        # Simulate key generation
        import secrets
        private_key = secrets.token_bytes(32)
        public_key = hashlib.sha256(private_key).digest()
        
        return {
            'algorithm': 'Kyber-post-quantum',
            'private_key': private_key.hex(),
            'public_key': public_key.hex(),
            'regenerated_at': self._get_current_time(),
            'source_entropy': 'TSU'  # Thermal Sampling Unit
        }
    
    def _get_current_time(self) -> float:
        """
        Get current timestamp
        
        Returns:
            float: Current time in seconds since epoch
        """
        import time
        return time.time()

# Example usage and security analysis
if __name__ == "__main__":
    # Create a blockchain and security model
    blockchain = Blockchain()
    security = SecurityModel(blockchain)
    
    # Create sample transactions
    tx1 = Transaction(
        inputs=[{"tx_id": "input1", "output_index": 0, "amount": 100}],
        outputs=[{"address": "addr1", "amount": 100}]
    )
    
    tx2 = Transaction(
        inputs=[{"tx_id": "input2", "output_index": 0, "amount": 50}],
        outputs=[{"address": "addr2", "amount": 50}]
    )
    
    # Test double-execution prevention
    print("Testing double-execution prevention:")
    is_safe1 = security.prevent_double_execution(tx1)
    print(f"First execution of tx1: {'Safe' if is_safe1 else 'Blocked'}")
    
    is_safe2 = security.prevent_double_execution(tx1)  # Same transaction
    print(f"Second execution of tx1: {'Safe' if is_safe2 else 'Blocked'}")
    
    # Test attack probability calculation
    print("\nTesting attack probability calculation:")
    attacker_power = 0.45  # 45% hash power
    confirmations = 6
    attack_prob = security.calculate_attack_probability(attacker_power, confirmations)
    print(f"Attack probability with {attacker_power*100}% attacker power and {confirmations} confirmations: {attack_prob:.6f}")
    
    # Test forking safety
    print("\nTesting forking safety:")
    chain_length = 10
    is_safe = security.is_fork_safe(chain_length, attacker_power)
    print(f"Chain safe from forking attacks: {is_safe}")
    
    # Test delta-Merkle updates
    print("\nTesting delta-Merkle updates:")
    old_state = {
        'kernel_version': '1.0.0',
        'security_level': 'high',
        'modules': ['network', 'storage', 'crypto']
    }
    
    new_state = {
        'kernel_version': '1.0.1',  # Updated
        'security_level': 'high',
        'modules': ['network', 'storage', 'crypto', 'ui'],  # Added module
        'new_feature': 'enabled'  # New key
    }
    
    is_update_safe = security.apply_delta_merkle_update(old_state, new_state)
    print(f"Delta-Merkle update safe: {is_update_safe}")
    
    # Test post-quantum key regeneration
    print("\nTesting post-quantum key regeneration:")
    new_keys = security.regenerate_post_quantum_keys()
    print(f"Generated post-quantum keys with algorithm: {new_keys['algorithm']}")